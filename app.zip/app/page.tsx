import HomeClient from "./home/HomeClient";

export default function Page() {
  return <HomeClient />;
}
